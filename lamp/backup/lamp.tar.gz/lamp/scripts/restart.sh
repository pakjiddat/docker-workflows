sudo docker exec -it lamp-apps bash  -c "service mysql restart;service apache2 restart"
