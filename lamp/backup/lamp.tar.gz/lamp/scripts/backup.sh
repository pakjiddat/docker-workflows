sudo tar -cvzf ../lamp-backup.tar.gz  .
mv ../lamp-backup.tar.gz backup/ 
