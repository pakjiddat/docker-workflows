sudo docker rm lamp-apps
