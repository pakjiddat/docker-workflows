sudo docker start lamp-apps

