sudo docker exec -it lamp-apps /bin/bash
