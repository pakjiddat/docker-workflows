sudo docker exec -it lamp-apps bash  -c "service mysql start;service apache2 start"
