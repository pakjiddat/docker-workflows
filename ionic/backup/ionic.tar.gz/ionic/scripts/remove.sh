sudo docker rm ionic
