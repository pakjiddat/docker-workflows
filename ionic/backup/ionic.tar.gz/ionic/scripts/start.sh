sudo docker start ionic
