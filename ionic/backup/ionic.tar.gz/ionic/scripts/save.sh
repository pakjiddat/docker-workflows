export $repo_name="ionic-framework:5.0.1"

sudo docker commit ionic $repo_name
