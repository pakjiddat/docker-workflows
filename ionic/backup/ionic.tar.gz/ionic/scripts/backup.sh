sudo tar -cvzf ../ionic-backup.tar.gz  .
mv ../ionic-backup.tar.gz backup/ 
