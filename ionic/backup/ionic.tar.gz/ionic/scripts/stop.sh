sudo docker stop ionic
