sudo docker exec -it ionic /bin/bash
