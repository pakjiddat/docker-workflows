sudo docker exec -it nodejs-apps /bin/bash
