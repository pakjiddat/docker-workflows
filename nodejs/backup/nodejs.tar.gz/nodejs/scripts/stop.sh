sudo docker stop nodejs-apps
