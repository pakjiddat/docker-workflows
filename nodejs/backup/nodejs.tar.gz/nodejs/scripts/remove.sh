sudo docker rm nodejs-apps
