sudo tar -cvzf ../nodejs-backup.tar.gz  .
mv ../nodejs-backup.tar.gz backup/
