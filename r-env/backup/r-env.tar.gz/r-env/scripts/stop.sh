sudo docker stop r-env 
