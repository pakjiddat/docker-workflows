sudo docker rm r-env 
