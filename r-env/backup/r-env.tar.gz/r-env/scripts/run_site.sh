sudo docker exec -it r-env bash  -c "service rstudio-server start"
