sudo docker exec -it r-env /bin/bash
