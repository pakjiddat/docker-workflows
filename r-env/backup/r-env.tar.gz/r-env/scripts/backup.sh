sudo tar -cvzf ../r-env-backup.tar.gz  .
mv ../r-env-backup.tar.gz backup/ 
