sudo docker start r-env
